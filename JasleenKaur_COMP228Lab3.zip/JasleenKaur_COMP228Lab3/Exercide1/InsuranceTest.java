import java.util.Scanner;

public class InsuranceTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Insurance[] insurances = new Insurance[2];  // Example for two insurance types

        for (int i = 0; i < insurances.length; i++) {
            System.out.print("Enter the type of insurance (Health/Life): ");
            String type = scanner.nextLine();

            if (type.equalsIgnoreCase("Health")) {
                insurances[i] = new Health();
            } else if (type.equalsIgnoreCase("Life")) {
                insurances[i] = new Life();
            }

            System.out.print("Enter the monthly fee: ");
            double cost = scanner.nextDouble();
            scanner.nextLine();  // Clear the newline character

            insurances[i].setInsuranceCost(cost);
        }

        // Display info for all insurances
        System.out.println("\nInsurance Information:");
        for (Insurance insurance : insurances) {
            insurance.displayInfo();
            System.out.println();
        }

        scanner.close();
    }
}
