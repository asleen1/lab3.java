package Exercise2;

public abstract class GameTester {
    protected String name;
    protected boolean isFullTime;

    public GameTester(String name, boolean isFullTime) {
        this.name = name;
        this.isFullTime = isFullTime;
    }

    // Abstract method to calculate salary
    public abstract double determineSalary();

    // Method to display game tester information
    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Full-time: " + isFullTime);
        System.out.println("Salary: $" + determineSalary());
    }
}
