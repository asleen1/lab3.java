package Exercise2;

public class FullTimeGameTester extends GameTester {

    public FullTimeGameTester(String name) {
        super(name, true); // Full-time tester, so isFullTime is true
    }

    @Override
    public double determineSalary() {
        return 3000;  // Base salary for full-time testers
    }
}
