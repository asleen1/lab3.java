package Exercise2;

import java.util.Scanner;

public class GameTesterTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Getting tester's name
        System.out.print("Enter the name of the game tester: ");
        String name = scanner.nextLine();

        // Asking if tester is full-time or part-time
        System.out.print("Is the game tester full-time? (yes/no): ");
        boolean isFullTime = scanner.nextLine().equalsIgnoreCase("yes");

        GameTester tester;

        if (isFullTime) {
            tester = new FullTimeGameTester(name);  // Create a full-time tester
        } else {
            // Asking for hours worked if part-time
            System.out.print("Enter the number of hours worked: ");
            int hoursWorked = scanner.nextInt();
            tester = new PartTimeGameTester(name, hoursWorked);  // Create a part-time tester
        }

        // Display game tester information
        tester.displayInfo();
        scanner.close();
    }
}
