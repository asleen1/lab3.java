package Exercise3;

import java.util.Scanner;

public class ProcessMortgage {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Array to hold 3 mortgage objects
        Mortgage[] mortgages = new Mortgage[3];

        // Prompting the user for the current prime interest rate
        System.out.print("Enter the current prime interest rate: ");
        double primeRate = scanner.nextDouble();

        // Loop to enter 3 mortgage details
        for (int i = 0; i < 3; i++) {
            System.out.println("\nEnter details for mortgage " + (i + 1));

            // Getting common mortgage details
            System.out.print("Enter mortgage number: ");
            int mortgageNumber = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter customer name: ");
            String customerName = scanner.nextLine();

            System.out.print("Enter mortgage amount: ");
            double mortgageAmount = scanner.nextDouble();

            System.out.print("Enter term (1 for Short-term, 3 for Medium-term, 5 for Long-term): ");
            int term = scanner.nextInt();

            // Asking for mortgage type
            System.out.print("Enter mortgage type (1 for Business, 2 for Personal): ");
            int mortgageType = scanner.nextInt();

            // Creating appropriate mortgage object based on user input
            if (mortgageType == 1) {
                mortgages[i] = new BusinessMortgage(mortgageNumber, customerName, mortgageAmount, primeRate, term);
            } else if (mortgageType == 2) {
                mortgages[i] = new PersonalMortgage(mortgageNumber, customerName, mortgageAmount, primeRate, term);
            } else {
                System.out.println("Invalid mortgage type entered.");
                i--; // Decrement to retry entering valid mortgage
            }
        }

        // Displaying mortgage details
        System.out.println("\nDisplaying all mortgage information:");
        for (Mortgage mortgage : mortgages) {
            if (mortgage != null) {
                System.out.println("------------------------------");
                System.out.println(mortgage.getMortgageInfo());
                System.out.println("------------------------------");
            }
        }

        scanner.close();
    }
}
