package Exercise3;

public class BusinessMortgage extends Mortgage {
    
    // Constructor
    public BusinessMortgage(int mortgageNumber, String customerName, double mortgageAmount, double primeRate, int term) {
        super(mortgageNumber, customerName, mortgageAmount, primeRate + 1.0, term); // Add 1% for business mortgages
    }

    @Override
    public double calculateTotalAmount() {
        return mortgageAmount + (mortgageAmount * (interestRate / 100) * term); // Total amount with interest
    }
}
