package Exercise3;

public abstract class Mortgage implements MortgageConstants {
    protected int mortgageNumber;
    protected String customerName;
    protected double mortgageAmount;
    protected double interestRate;
    protected int term;

    // Constructor
    public Mortgage(int mortgageNumber, String customerName, double mortgageAmount, double interestRate, int term) {
        this.mortgageNumber = mortgageNumber;
        this.customerName = customerName;
        
        // Ensuring mortgage amount does not exceed MAX_MORTGAGE_AMOUNT
        if (mortgageAmount > MAX_MORTGAGE_AMOUNT) {
            this.mortgageAmount = MAX_MORTGAGE_AMOUNT;
        } else {
            this.mortgageAmount = mortgageAmount;
        }

        this.interestRate = interestRate;

        // Ensure term is within the constants provided
        if (term != SHORT_TERM && term != MEDIUM_TERM && term != LONG_TERM) {
            this.term = SHORT_TERM; // Default to 1 year if an invalid term is provided
        } else {
            this.term = term;
        }
    }

    // Abstract method to be implemented by subclasses
    public abstract double calculateTotalAmount();

    // Method to get mortgage information
    public String getMortgageInfo() {
        return "Mortgage Number: " + mortgageNumber +
               "\nCustomer Name: " + customerName +
               "\nMortgage Amount: $" + mortgageAmount +
               "\nInterest Rate: " + interestRate + "%" +
               "\nTerm: " + term + " year(s)" +
               "\nTotal Amount Owed: $" + calculateTotalAmount();
    }
}
