package Exercise3;

public class PersonalMortgage extends Mortgage {

    // Constructor
    public PersonalMortgage(int mortgageNumber, String customerName, double mortgageAmount, double primeRate, int term) {
        super(mortgageNumber, customerName, mortgageAmount, primeRate + 2.0, term); // Add 2% for personal mortgages
    }

    @Override
    public double calculateTotalAmount() {
        return mortgageAmount + (mortgageAmount * (interestRate / 100) * term); // Total amount with interest
    }
}
