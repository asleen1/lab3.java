package Exercise3;

public interface MortgageConstants {
    public static final int SHORT_TERM = 1;     // 1 year
    public static final int MEDIUM_TERM = 3;    // 3 years
    public static final int LONG_TERM = 5;      // 5 years
    public static final String BANK_NAME = "CityToronto Bank";
    public static final double MAX_MORTGAGE_AMOUNT = 300000;
}
